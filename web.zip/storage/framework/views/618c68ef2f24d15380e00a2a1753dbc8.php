<?php if (isset($component)) { $__componentOriginal165f8e34452936f6da18fceb86497519 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal165f8e34452936f6da18fceb86497519 = $attributes; } ?>
<?php $component = App\View\Components\App::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card card-outline card-primary">

        <div class="card-body register-card-body">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-info text-center" role="alert">
                    <strong class="text-center" style="font-size: 20px;"><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            <p class="register-box-msg">Data Peserta Sertifikasi Mahasiswa Prodi Teknologi Informasi</p>

            <div class="row mb-2">
                <div class="col-sm-12">

                    <h4 class="loginleft"> Junior Web Programing</h4>

                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 40%">NIM </th>
                                <th class="text-center">Nama</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $list_data_pendaftar->where('jenis_sertifikasi', 'Junior Web Programing'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pendaftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($data_pendaftar->nim); ?></td>
                                    <td class="text-center"><?php echo e($data_pendaftar->nama_mahasiswa); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-sm-12">

                    <h4 class="loginleft"> Junior Grapich Designer</h4>

                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 40%">NIM </th>
                                <th class="text-center">Nama</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $list_data_pendaftar->where('jenis_sertifikasi', 'Junior Grapich Designer'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pendaftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($data_pendaftar->nim); ?></td>
                                    <td class="text-center"><?php echo e($data_pendaftar->nama_mahasiswa); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

          
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $attributes = $__attributesOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__attributesOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal165f8e34452936f6da18fceb86497519)): ?>
<?php $component = $__componentOriginal165f8e34452936f6da18fceb86497519; ?>
<?php unset($__componentOriginal165f8e34452936f6da18fceb86497519); ?>
<?php endif; ?>
<?php /**PATH F:\github\sertifikasi\resources\views/peserta/data-pendaftar.blade.php ENDPATH**/ ?>